pita - Order pack for Guangzhou Tropical Rainforest Industrial Co., Ltd. (Attn: Suki Li)

pita-order-pack.pdf
  p.1    Our first order + design photos
  p.2    Price breakdown (please complete)
  p.3    Branding confirmation before payment (please confirm each point)
  p.4-9  pita brand guide: brand, colors, gift box, what's inside, device, flavor refills

artwork/ Print files: gift box, flavor pouches, device engraving, cloth, welcome letter, envelope, full kit overview
photos/  Design reference photos (mock-ups)
logo/    Logo files (SVG, filled shapes). pita-engraving-1color.svg = laser engraving on the wood.
