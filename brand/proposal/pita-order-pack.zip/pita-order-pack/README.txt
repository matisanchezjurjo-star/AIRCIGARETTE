pita - Order pack for Guangzhou Tropical Rainforest Industrial Co., Ltd. (Attn: Suki Li)

pita-order-pack.pdf
  p.1    Our first order + design photos
  p.2    Price breakdown (please complete)
  p.3    Branding confirmation before payment (please confirm each point)
  p.4-7  pita brand guide: brand, colors, gift box, device, flavor refills

photos/  Design reference photos (mock-ups)
logo/    Logo files (SVG). pita-engraving-1color.svg = laser engraving on the wood.
         Logos are filled shapes (no strokes). AI/PDF versions available on request.
